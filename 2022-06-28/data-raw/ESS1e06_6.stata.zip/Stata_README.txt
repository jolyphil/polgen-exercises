This is a Stata 10 file. If you are unable to open it using Stata, you may be using an older version than Stata 10. Please contact ESS Data Support at essdatasupport@nsd.no, and we will provide you with a file that works with your version.

Note that missing values have been recode from ESS' usual missing values to Stata's missing values:
Not applicable (6/66/666 etc) -> .a
Refusal (7/77/777 etc) -> .b
Don�t know (8/88/888 etc) -> .c
No answer/Not available (9/99/999 etc) -> .d

In previous editions of this file, missing values were recoded by the user with the included ESS_miss.do syntax. They are now recoded at the archive before the file is downloaded.